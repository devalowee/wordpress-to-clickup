<?php
add_action('admin_menu', function () {
    add_menu_page(
        'ClickUp Integración',
        'ClickUp Integración',
        'manage_options',
        'clickup-integration',
        'clickup_admin_panel_html',
        'dashicons-clipboard',
        80
    );
});

function clickup_admin_panel_html() {
    ?>
    <div class="wrap">
        <h1>Configuración de ClickUp</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('clickup_settings_group');
            do_settings_sections('clickup-integration');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', function () {
    register_setting('clickup_settings_group', 'clickup_api_token');
    register_setting('clickup_settings_group', 'clickup_list_id');

    add_settings_section('clickup_section', 'Credenciales', null, 'clickup-integration');

    add_settings_field('clickup_api_token', 'API Token', function () {
        $value = esc_attr(get_option('clickup_api_token'));
        echo "<input type='password' name='clickup_api_token' value='$value' class='regular-text' />";
    }, 'clickup-integration', 'clickup_section');

    add_settings_field('clickup_list_id', 'List ID (ClickUp)', function () {
        $value = esc_attr(get_option('clickup_list_id'));
        echo "<input type='text' name='clickup_list_id' value='$value' class='regular-text' />";
    }, 'clickup-integration', 'clickup_section');
});
?>