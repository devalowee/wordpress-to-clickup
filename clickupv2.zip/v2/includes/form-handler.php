<?php
  add_action('rest_api_init', function () {
      register_rest_route('clickup/v1', '/webhook/', array(
          'methods'  => 'POST',
          'callback' => 'clickup_webhook_handler',
          'permission_callback' => '__return_true',
      ));
  });

  function clickup_webhook_handler(WP_REST_Request $request) {
      $data = $request->get_json_params();

      if (isset($data['event']) && in_array($data['event'], ['taskCreated', 'taskUpdated'])) {
          file_put_contents(WP_CONTENT_DIR . "/clickup-webhook.log", "⛔ Ignorado: evento {$data['event']} desde ClickUp
  ", FILE_APPEND);
          return rest_ensure_response(['status' => 'ignored']);
      }

      $log_path = WP_CONTENT_DIR . "/clickup-webhook.log";
      file_put_contents($log_path, "📥 Recibido en Webhook: " . json_encode($data, JSON_PRETTY_PRINT) . "
  ", FILE_APPEND);

      $hidden = trim($data["hidden"] ?? '');

      if (is_array($data["nombre"] ?? null)) {
          $solicitante = trim(($data["nombre"]["first_name"] ?? '') . ' ' . ($data["nombre"]["last_name"] ?? ''));
      } else {
          $solicitante = trim($data["nombre"] ?? '');
      }

      $fecha = trim($data["fecha_de_envio"] ?? date('Y-m-d'));
      $nombreFormulario = $hidden . ' - ' . $solicitante . ' - ' . $fecha;

      if (empty(trim($nombreFormulario))) {
          file_put_contents($log_path, "❌ Nombre vacío. No se envía a ClickUp.
  ", FILE_APPEND);
          return rest_ensure_response(['status' => 'error', 'message' => 'Nombre vacío']);
      }

      $payload = [
          "name" => $nombreFormulario,
          "description" => format_all_fields($data),
          "status" => "nueva"
      ];

      file_put_contents($log_path, "📦 Payload enviado:
  " . json_encode($payload, JSON_PRETTY_PRINT) . "
  ", FILE_APPEND);

      $response = send_to_clickup($payload);
      file_put_contents($log_path, "📥 Respuesta ClickUp: " . print_r($response, true) . "
  ", FILE_APPEND);

      return rest_ensure_response(['status' => 'success', 'clickup_response' => $response]);
  }

  function format_all_fields($data) {
      unset($data["_fluentform_3_fluentformnonce"], $data["__submission"]);
      $output = "📝 Datos del formulario:

  ";
      foreach ($data as $key => $value) {
          if ($key === 'hidden') {
              $label = 'Tipo de Solicitud';
          } else {
              $label = ucwords(str_replace(['-', '_'], ' ', $key));
          }

          if ($key === 'nombre' && is_array($value)) {
              $value = trim(($value['first_name'] ?? '') . ' ' . ($value['last_name'] ?? ''));
          }

          if (is_array($value)) {
              if (filter_var($value[0] ?? '', FILTER_VALIDATE_URL)) {
                  $urls = '';
                  foreach ($value as $url) {
                      $urls .= "[Descargar adjunto]($url)
  ";
                  }
                  $value = trim($urls);
              } else {
                  $value = json_encode($value);
              }
          }

          $output .= "• $label: $value
  ";
      }
      return trim($output);
  }

  function send_to_clickup($payload) {
      $clickup_api_token = get_option('clickup_api_token');
      $list_id = get_option('clickup_list_id');

      if (empty($clickup_api_token) || empty($list_id)) {
          file_put_contents(WP_CONTENT_DIR . "/clickup-webhook.log", "❌ Error: API Token o List ID no configurados
", FILE_APPEND);
          return ['error' => 'Configuración incompleta'];
      }

      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "https://api.clickup.com/api/v2/list/$list_id/task");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
      curl_setopt($ch, CURLOPT_HTTPHEADER, [
          "Authorization: Bearer $clickup_api_token",
          "Content-Type: application/json"
      ]);

      $response = curl_exec($ch);
      
      if (curl_errno($ch)) {
          file_put_contents(WP_CONTENT_DIR . "/clickup-webhook.log", "❌ Error cURL: " . curl_error($ch) . "
", FILE_APPEND);
          curl_close($ch);
          return ['error' => 'Error de conexión'];
      }

      $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);

      if ($http_code !== 200) {
          file_put_contents(WP_CONTENT_DIR . "/clickup-webhook.log", "❌ Error HTTP: $http_code - Respuesta: $response
", FILE_APPEND);
          return ['error' => 'Error de API', 'code' => $http_code];
      }

      return json_decode($response, true);
  }
?>