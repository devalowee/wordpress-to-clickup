<?php
// Funciones compartidas para el plugin
?>