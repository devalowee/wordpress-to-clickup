<?php
add_action('admin_menu', function () {
    add_menu_page(
        'ClickUp Integration',
        'ClickUp Integration',
        'manage_options',
        'clickup-integration',
        'clickup_admin_panel_html',
        'dashicons-clipboard',
        80
    );
});

function get_last_log_errors($count = 5) {
    $log_path = WP_CONTENT_DIR . "/clickup-webhook.log";
    if (!file_exists($log_path)) {
        return [];
    }
    
    $log_content = file_get_contents($log_path);
    if (empty($log_content)) {
        return [];
    }
    
    $entries = explode("\n", $log_content);
    $errors = [];
    
    foreach ($entries as $entry) {
        if (strpos($entry, '❌') !== false) {
            $errors[] = $entry;
            if (count($errors) >= $count) {
                break;
            }
        }
    }
    
    return array_reverse($errors);
}

function clickup_admin_panel_html() {
    $webhook_url = get_site_url() . '/wp-json/clickup/v1/webhook/';
    $webhook_key = get_option('clickup_webhook_key');
    $errors = get_last_log_errors();
    ?>
    <div class="wrap">
        <h1>ClickUp Integration Configuration</h1>
        
        <div class="card" style="max-width: 800px; margin-bottom: 20px; padding: 15px;">
            <h2>Instructions</h2>
            <p>To use this plugin, configure your form with these required fields:</p>
            <ul style="list-style-type: disc; margin-left: 20px;">
                <li><strong>source</strong>: Title/name of the task</li>
                <li><strong>date</strong>: Date when the request was sent</li>
                <li><strong>name</strong>: Name of the responsible person (optional)</li>
            </ul>
            
            <h3>Webhook URL</h3>
            <div style="background: #f0f0f1; padding: 10px; border-radius: 4px;">
                <code style="font-size: 14px;"><?php echo esc_html($webhook_url); ?></code>
                <button type="button" class="button" onclick="navigator.clipboard.writeText('<?php echo esc_js($webhook_url); ?>')">Copy URL</button>
            </div>
            
            <h3>Security Header (Required)</h3>
            <div style="background: #f0f0f1; padding: 10px; border-radius: 4px; margin-top: 10px;">
                <strong>Header Name:</strong> <code>X-Clickup-Webhook-Key</code><br>
                <strong>Header Value:</strong> <code><?php echo esc_html($webhook_key); ?></code>
                <button type="button" class="button" onclick="navigator.clipboard.writeText('<?php echo esc_js($webhook_key); ?>')">Copy Key</button>
            </div>
            <p class="description" style="color: #d63638; font-weight: bold;">Security notice: All requests must include the security header. Requests without a valid key will be rejected.</p>
            
            <div style="margin-top: 15px; background: #f0f8ff; border-left: 4px solid #2271b1; padding: 10px;">
                <h4 style="margin-top: 0;">Example cURL request:</h4>
                <pre style="white-space: pre-wrap; word-break: break-all; background: #f8f9fa; padding: 8px; font-size: 12px; overflow-x: auto;">curl -X POST \
  <?php echo esc_html($webhook_url); ?> \
  -H 'Content-Type: application/json' \
  -H 'X-Clickup-Webhook-Key: <?php echo esc_html($webhook_key); ?>' \
  -d '{
    "source": "Example Task",
    "date": "<?php echo date('Y-m-d'); ?>",
    "name": "John Doe"
}'</pre>
            </div>
        </div>
        
        <?php if (!empty($errors)): ?>
        <div class="card" style="max-width: 800px; margin-bottom: 20px; padding: 15px; border-left: 4px solid #dc3232;">
            <h2><span class="dashicons dashicons-warning" style="color: #dc3232;"></span> Recent Errors</h2>
            <div style="background: #f0f0f1; padding: 10px; border-radius: 4px; max-height: 200px; overflow-y: auto;">
                <?php foreach ($errors as $error): ?>
                <div style="margin-bottom: 8px; font-family: monospace;"><?php echo esc_html($error); ?></div>
                <?php endforeach; ?>
            </div>
            <p>
                <a href="<?php echo admin_url('admin.php?page=clickup-integration&clear_log=1'); ?>" class="button">Clear log</a>
            </p>
        </div>
        <?php endif; ?>
        
        <form method="post" action="options.php">
            <?php
            settings_fields('clickup_settings_group');
            do_settings_sections('clickup-integration');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Handle log clearing
add_action('admin_init', function() {
    if (isset($_GET['page']) && $_GET['page'] === 'clickup-integration' && 
        isset($_GET['clear_log']) && current_user_can('manage_options')) {
        $log_path = WP_CONTENT_DIR . "/clickup-webhook.log";
        if (file_exists($log_path)) {
            file_put_contents($log_path, "");
            wp_redirect(admin_url('admin.php?page=clickup-integration&log_cleared=1'));
            exit;
        }
    }
    
    if (isset($_GET['log_cleared'])) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>The log has been cleared successfully.</p></div>';
        });
    }
});

add_action('admin_init', function () {
    register_setting('clickup_settings_group', 'clickup_api_token');
    register_setting('clickup_settings_group', 'clickup_list_id');
    register_setting('clickup_settings_group', 'clickup_task_status');
    register_setting('clickup_settings_group', 'clickup_webhook_key');

    add_settings_section('clickup_section', 'Credentials', null, 'clickup-integration');

    add_settings_field('clickup_api_token', 'API Token', function () {
        $value = esc_attr(get_option('clickup_api_token'));
        echo "<input type='password' name='clickup_api_token' value='$value' class='regular-text' />";
        echo "<p class='description'>Enter your ClickUp API Token. You can generate it in <a href='https://app.clickup.com/settings/apps' target='_blank'>Settings > Apps</a>.</p>";
    }, 'clickup-integration', 'clickup_section');

    add_settings_field('clickup_list_id', 'List ID (ClickUp)', function () {
        $value = esc_attr(get_option('clickup_list_id'));
        echo "<input type='text' name='clickup_list_id' value='$value' class='regular-text' />";
        echo "<p class='description'>The ID of the list where tasks will be created. You can find it in the URL when viewing the list.</p>";
    }, 'clickup-integration', 'clickup_section');
    
    add_settings_field('clickup_task_status', 'Initial Task Status', function () {
        $value = esc_attr(get_option('clickup_task_status', 'new'));
        echo "<input type='text' name='clickup_task_status' value='$value' class='regular-text' />";
        echo "<p class='description'>The initial status for created tasks in ClickUp (e.g., new, to do, in progress, etc). Must exactly match one of the statuses in your ClickUp workspace.</p>";
    }, 'clickup-integration', 'clickup_section');
    
    add_settings_field('clickup_webhook_key', 'Webhook Security Key', function () {
        $value = esc_attr(get_option('clickup_webhook_key'));
        if (empty($value)) {
            $value = wp_generate_password(24, false);
            update_option('clickup_webhook_key', $value);
        }
        echo "<input type='text' name='clickup_webhook_key' value='$value' class='regular-text' />";
        echo "<p class='description'>This key must be included in all webhook requests as a <code>X-Clickup-Webhook-Key</code> header for security. Keep it secret!</p>";
    }, 'clickup-integration', 'clickup_section');
});
?>