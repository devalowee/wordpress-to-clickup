<?php
  add_action('rest_api_init', function () {
      register_rest_route('clickup/v1', '/webhook/', array(
          'methods'  => 'POST',
          'callback' => 'clickup_webhook_handler',
          'permission_callback' => '__return_true',
      ));
  });

  /**
   * Helper function to write to log with timestamp
   */
  function log_with_timestamp($message) {
      $log_path = WP_CONTENT_DIR . "/clickup-webhook.log";
      $timestamp = '[' . date('Y-m-d H:i:s') . '] ';
      file_put_contents($log_path, $timestamp . $message . "\n", FILE_APPEND);
  }

  function clickup_webhook_handler(WP_REST_Request $request) {
      // Skip validation for WordPress admin actions
      $referer = $request->get_header('referer');
      if ($referer && (strpos($referer, 'wp-admin') !== false || strpos($referer, 'options.php') !== false)) {
          return rest_ensure_response(['status' => 'admin_access']);
      }
      
      // Validate security key using HTTP header
      $webhook_key = get_option('clickup_webhook_key');
      $request_key = $request->get_header('X-Clickup-Webhook-Key');
      
      if (empty($webhook_key) || $webhook_key !== $request_key) {
          log_with_timestamp("❌ Security validation failed. Invalid or missing key in header.");
          return new WP_Error('unauthorized', 'Invalid security key', ['status' => 401]);
      }
      
      $data = $request->get_json_params();

      if (isset($data['event']) && in_array($data['event'], ['taskCreated', 'taskUpdated'])) {
          log_with_timestamp("⛔ Ignored: event {$data['event']} from ClickUp");
          return rest_ensure_response(['status' => 'ignored']);
      }

      log_with_timestamp("📥 Received in Webhook: " . json_encode($data, JSON_PRETTY_PRINT));

      $source = trim($data["source"] ?? '');

      if (is_array($data["name"] ?? null)) {
          $requester = trim(($data["name"]["first_name"] ?? '') . ' ' . ($data["name"]["last_name"] ?? ''));
      } else {
          $requester = trim($data["name"] ?? '');
      }

      $date = trim($data["date"] ?? date('Y-m-d'));
      $taskName = $source . ' - ' . $requester . ' - ' . $date;

      if (empty(trim($taskName))) {
          log_with_timestamp("❌ Empty name. Not sending to ClickUp.");
          return rest_ensure_response(['status' => 'error', 'message' => 'Empty name']);
      }

      $payload = [
          "name" => $taskName,
          "description" => format_all_fields($data),
          "status" => get_option('clickup_task_status', 'new')
      ];

      log_with_timestamp("📦 Payload sent:\n" . json_encode($payload, JSON_PRETTY_PRINT));

      $response = send_to_clickup($payload);
      log_with_timestamp("📥 ClickUp Response: " . print_r($response, true));

      return rest_ensure_response(['status' => 'success', 'clickup_response' => $response]);
  }

  function format_all_fields($data) {
      unset($data["_fluentform_3_fluentformnonce"], $data["__submission"]);
      $output = "📝 Form data:\n\n";
      foreach ($data as $key => $value) {
          if ($key === 'source') {
              $label = 'Request Type';
          } else {
              $label = ucwords(str_replace(['-', '_'], ' ', $key));
          }

          if ($key === 'name' && is_array($value)) {
              $value = trim(($value['first_name'] ?? '') . ' ' . ($value['last_name'] ?? ''));
          }

          if (is_array($value)) {
              if (filter_var($value[0] ?? '', FILTER_VALIDATE_URL)) {
                  $urls = '';
                  foreach ($value as $url) {
                      $urls .= "[Download attachment]($url)\n";
                  }
                  $value = trim($urls);
              } else {
                  $value = json_encode($value);
              }
          }

          $output .= "• $label: $value\n";
      }
      return trim($output);
  }

  function send_to_clickup($payload) {
      $clickup_api_token = get_option('clickup_api_token');
      $list_id = get_option('clickup_list_id');

      if (empty($clickup_api_token) || empty($list_id)) {
          log_with_timestamp("❌ Error: API Token or List ID not configured");
          return ['error' => 'Incomplete configuration'];
      }

      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "https://api.clickup.com/api/v2/list/$list_id/task");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
      curl_setopt($ch, CURLOPT_HTTPHEADER, [
          "Authorization: Bearer $clickup_api_token",
          "Content-Type: application/json"
      ]);

      $response = curl_exec($ch);
      
      if (curl_errno($ch)) {
          log_with_timestamp("❌ cURL Error: " . curl_error($ch));
          curl_close($ch);
          return ['error' => 'Connection error'];
      }

      $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);

      if ($http_code !== 200) {
          log_with_timestamp("❌ HTTP Error: $http_code - Response: $response");
          return ['error' => 'API Error', 'code' => $http_code];
      }

      return json_decode($response, true);
  }
?>