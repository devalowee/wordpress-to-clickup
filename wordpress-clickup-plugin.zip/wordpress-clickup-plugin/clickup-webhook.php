<?php
/**
 * Plugin Name: ClickUp Webhook Integration
 * Description: Admin panel to connect FluentForms forms with ClickUp.
 * Version: 2.1.4
 * Author: Alowee
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/admin-panel.php';
require_once plugin_dir_path(__FILE__) . 'includes/form-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/functions.php';
?>