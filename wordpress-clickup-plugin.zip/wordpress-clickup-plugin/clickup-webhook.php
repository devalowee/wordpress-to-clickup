<?php
/**
 * Plugin Name: ClickUp Webhook Integration
 * Description: Admin panel to connect FluentForms forms with ClickUp.
 * Version: 2.1.5
 * Author: Alowee
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/admin-panel.php';
require_once plugin_dir_path(__FILE__) . 'includes/form-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/functions.php';
?>