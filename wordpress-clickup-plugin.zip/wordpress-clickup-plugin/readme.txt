=== ClickUp Webhook Integration ===
Contributors: alowee
Tags: clickup, webhook, fluentforms
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 2.1.4
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrates FluentForms with ClickUp through webhooks.

== Description ==

Plugin that connects FluentForms with ClickUp. Automatically creates tasks when forms are submitted.

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` folder
2. Activate the plugin in the WordPress 'Plugins' menu
3. Go to 'ClickUp Integration' in the WordPress menu
4. Configure your ClickUp API Token and List ID
5. Use the webhook URL and security header provided in the admin panel

== Requirements ==

* WordPress 5.0 or higher
* PHP 7.4 or higher
* FluentForms installed and configured
* ClickUp account with API Token

== Changelog ==

= 2.1.4 =
* Added timestamps to all log entries for better troubleshooting
* Improved log format with consistent formatting

= 2.1.3 =
* Fixed bug: Prevented false error logs during admin actions
* Improved webhook handler to ignore internal WordPress admin requests

= 2.1.2 =
* Enhanced security: Now uses HTTP header for API key instead of URL parameter
* Added example cURL request to admin panel
* Improved security documentation

= 2.1.1 =
* Added webhook security key validation
* Improved endpoint security against unauthorized access
* Updated all strings to English

= 2.1.0 =
* Added error section in admin panel
* Added button to clear error log
* Implemented field to configure initial task status in ClickUp
* Improved error handling in ClickUp API communication
* Added webhook URL in panel for easier use

= 2.0.0 =
* Initial version with admin panel

== Support ==

For support, contact: support@alowee.com

This plugin works to send data from a json to Clickup and convert it into a task.

When installing it, you must configure your webhook like this:
It must contain the following mandatory fields:
* \"source\" => In this field you must define the title/name that the task will have
* \"date\" => In this field, you must define the date on which the request is sent
* \"name\" => In this field you define the name of the person responsible for the request (optional)

These fields are mandatory, and without them, you may receive an error.

The webhook must include the security key as an HTTP header (X-Clickup-Webhook-Key) in all requests. 
Requests without a valid security header will be rejected with a 401 error.

In the plugin admin panel, you must enter your API_TOKEN and your LIST_ID.
If you need to make modifications, here is the code: https://github.com/devalowee/wordpress-to-clickup
